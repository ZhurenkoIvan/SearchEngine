package searchEngineApp.ENUMS;

public enum LemmaLanguage {
    RUS,
    ENG
}
